<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Pirata+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Teko:wght@300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <title>Tattoo</title>
</head>
<body>
<header>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-dark headernav">
            <a class="navbar-brand headernav__logo" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon headernav__icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ml-auto headernav__menu">
                    <li class="nav-item headernav__menu__item">
                        <a class="nav-link headernav__menu__item__a" href="#">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item headernav__menu__item">
                        <a class="nav-link headernav__menu__item__a" href="#">Features</a>
                    </li>
                    <li class="nav-item headernav__menu__item">
                        <a class="nav-link headernav__menu__item__a" href="#">Pricing</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>

<section class="paralax">
    <img src="img/tattoobg.jpg" class="paralax__img" alt="" id="bg">
    <img src="img/cobra.png" class="paralax__img" alt="" id="cobra">
    <h2 id="text">tattoo</h2>
</section>

<section class="header-banner">
    <div class="container-fluid">
        <div class="banner p-0">
            <div class="row">
                <div class="col-2 banner__img">
                    <img src="img/Lion_Tattoo_Left.png" class="banner__img__lion img-fluid d-none d-xl-block" alt="">                   
                </div>
                <div class="col-8 text-center banner__span">
                    <span class="banner__span__text">Part of Art Studio</span>                    
                </div>
                <div class="col-2 banner__img">
                    <img src="img/Lion_Tattoo_Right.png" class="banner__img__lion img-fluid d-none d-xl-block" alt="">                    
                </div>
            </div>
        </div>
    </div>
</section>
<section class="aboutbcg">
    <div class="container">
        <div class="about">
            <div class="row">
                <div class="col-sm-12 col-lg-6 about__img">
                    <img src="img/aboutimg.jpg" class="about__img__image" alt="">
                </div>
                <div class="col-sm-12 col-lg-6 about__welcome">
                    <span class="about__welcome__span">Witamy w naszym studiu</span>
                    <p class="about__welcome__p">Tatto Studio perspiciatis omnis iste natus laudantore veritatis et architecto beatae vitae nunc sagittis interdum risusut accumsan. Donec faucibus mauris ullamcorper elit feugiat consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a nulla ipsum. Curabitur pulvinar enim non justo cursus vestibulum. Praesent eu eros non turpis tempor sagittis in sit amet elit. Ut interdum sed neque elementum fermentum. 

                    Aommodn quam quo mollitia. Sint veniam autem consectetur dolore dolor, quidem iusto animi explicabo inventore fuga soluta.

                    Body Piercing adn Painting ipsum dolor sit amet, consectetur adipiscing elit. Sed a nulla ipsum. Curabitur pulvinar enim non justo cursus vestibulum. Praesent eu eros non turpis tempor sagittis in sit amet elit.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="artistsbgc">
    <div class="container">
        <div class="artists">
        
            <div class="row">
                <span class="artists__span">NASI&nbsp;ARTYŚCI</span>
            </div>
            <div class="row">
                <img src="img/Image_Seperator.png" class="artists__separator" alt="">
            </div>
            <div class="row">
                <div class="artists__window col-sm-4 col-lg-3 m-4">
                    <div class="artists__window__members">
                        <img class="artists__window__members__img" src="img/work1.jpg" alt="">
                        <span class="artists__window__members__span">Edyta W</span>
                        <span class="artists__window__members__function">tatuażysta</span>
                    </div>
                </div>
                <div class="artists__window col-sm-4 col-lg-3 m-4">
                    <div class="artists__window__members">
                        <img class="artists__window__members__img" src="img/work1.jpg" alt="">
                        <span class="artists__window__members__span">dziarski H</span>
                        <span class="artists__window__members__function">tatuażysta</span>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
<section class="featuredinkbgc">
    <div class="container">
        <div class="featuredink">
            <div class="row test">
                <span class="featuredink__span">NASZE&nbsp;PRACE</span>
            </div>
            <div class="row">
                <img src="img/Image_Seperator.png" class="featuredink__separator" alt="">
            </div>
        </div>
        <div class="row featuredink__works">
            <div class="featuredink__works__image col-4">
                <img src="img/work1.jpg" class="featuredink__works__image__img" alt="">
            </div>
            <div class="featuredink__works__image col-4">
                <img src="img/work2.jpg" class="featuredink__works__image__img" alt="">
            </div>
            <div class="featuredink__works__image col-4">
                <img src="img/work3.jpg" class="featuredink__works__image__img" alt="">
            </div>
        </div>
        <div class="row featuredink__works">
            <div class="featuredink__works__image col-4">
                <img src="img/work1.jpg" class="featuredink__works__image__img" alt="">
            </div>
            <div class="featuredink__works__image col-4">
                <img src="img/work2.jpg" class="featuredink__works__image__img" alt="">
            </div>
            <div class="featuredink__works__image col-4">
                <img src="img/work3.jpg" class="featuredink__works__image__img" alt="">
            </div>
        </div>
        <div class="row featuredink__works">
            <div class="featuredink__works__image col-4">
                <img src="img/work1.jpg" class="featuredink__works__image__img" alt="">
            </div>
            <div class="featuredink__works__image col-4">
                <img src="img/work2.jpg" class="featuredink__works__image__img" alt="">
            </div>
            <div class="featuredink__works__image col-4">
                <img src="img/work3.jpg" class="featuredink__works__image__img" alt="">
            </div>
        </div>
    </div>
</section>   
<footer>
    <div class="container footer">

    </div>
</footer>

</body>
</html>